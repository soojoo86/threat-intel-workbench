"""威胁情报工作台（TI Workbench）· 本地服务。

基于开源威胁情报采集代码（Apache-2.0，归属见 NOTICE）：
- collectors.py 原样复用上游公开源采集器（微步/长亭/斗象/阿里云/NVD/CISA KEV/Tenable/安全新闻 RSS）
- 本文件实现独立后端：SQLite 情报库 + 浏览/筛选 API + 手动同步 + 微步 IOC 查询（可选 apikey）
仅依赖 httpx（采集器使用），其余全部标准库，Windows 本地双击 start.bat 即可运行。
"""
import asyncio
import hashlib
import json
import re
import sqlite3
import threading
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "threat_intel.db"
CONFIG_PATH = ROOT / "config.json"

DEFAULT_CONFIG = {"port": 8686, "threatbook_api_key": "", "threatbook_region": "cn", "timeout": 30,
                  "auto_sync_enabled": False, "auto_sync_hours": 12, "custom_sources": [],
                  "disabled_sources": [],
                  "webhook_enabled": False, "webhook_url": "", "webhook_secret": "",
                  "webhook_min_severity": "high", "webhook_max_items": 10}

SYNC_LOCK = threading.Lock()
SYNC_STATE = {"running": False, "last_result": None}

def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            pass
    return cfg


def save_config(cfg):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def now():
    return datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS ti_items (
          id TEXT PRIMARY KEY, source TEXT NOT NULL, cve TEXT NOT NULL, title TEXT NOT NULL,
          published TEXT NOT NULL, info TEXT NOT NULL, url TEXT NOT NULL, severity TEXT NOT NULL,
          synced TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ti_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS ti_date ON ti_items(published);
        CREATE TABLE IF NOT EXISTS ti_sync_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL, trigger TEXT NOT NULL,
          fetched INTEGER NOT NULL, added INTEGER NOT NULL, updated INTEGER NOT NULL,
          sources TEXT NOT NULL, changes TEXT NOT NULL, webhook TEXT NOT NULL DEFAULT '');
        """)
        cols = [r[1] for r in con.execute("PRAGMA table_info(ti_sync_history)")]
        if "webhook" not in cols:
            con.execute("ALTER TABLE ti_sync_history ADD COLUMN webhook TEXT NOT NULL DEFAULT ''")


def meta_get(con, key, default=""):
    row = con.execute("SELECT value FROM ti_meta WHERE key=?", (key,)).fetchone()
    return row[0] if row else default


def meta_set(con, key, value):
    con.execute("INSERT OR REPLACE INTO ti_meta VALUES(?,?)", (key, value))
def persist_rows(con, rows, synced):
    """按上游逻辑简化：以 (source_id, key) 摘要为主键，URL/CVE 去重后增量入库。
    返回 (added, updated, changes)；changes 记录本次新增/更新条目明细，供同步历史展示。"""
    urls = {}
    for old in con.execute("SELECT id,source,url FROM ti_items"):
        urls[(old["source"], old["url"].rstrip("/"))] = old["id"]
    added = updated = 0
    changes = []
    for item in rows:
        iid = urls.get((item["source"], item["url"].rstrip("/"))) or digest(
            ["direct", item["source_id"], item["key"]])
        values = (item["source"], item["cve"], item["title"], item["published"],
                  item["info"], item["url"], item["severity"])
        old = con.execute("SELECT source,cve,title,published,info,url,severity FROM ti_items WHERE id=?", (iid,)).fetchone()
        if old and tuple(old) == values:
            continue
        con.execute("INSERT INTO ti_items VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET "
                    "source=excluded.source,cve=excluded.cve,title=excluded.title,published=excluded.published,"
                    "info=excluded.info,url=excluded.url,severity=excluded.severity,synced=excluded.synced",
                    (iid, *values, synced))
        if old:
            updated += 1
            action = "updated"
        else:
            added += 1
            action = "added"
        changes.append({"id": iid, "action": action, "source": item["source"], "cve": item["cve"],
                        "title": item["title"][:200], "severity": item["severity"],
                        "published": item["published"][:19]})
    return added, updated, changes


def seed_demo():
    """首次运行且库为空时导入内置演示情报（data/demo_items.json），保证离线也有内容可看。"""
    demo_path = ROOT / "data" / "demo_items.json"
    if not demo_path.exists():
        return
    with db() as con:
        if con.execute("SELECT 1 FROM ti_items LIMIT 1").fetchone():
            return
        rows = json.loads(demo_path.read_text(encoding="utf-8"))
        for item in rows:
            con.execute("INSERT OR IGNORE INTO ti_items VALUES(?,?,?,?,?,?,?,?,?)",
                        (digest(["demo", item["source"], item["title"]]), item["source"], item["cve"],
                         item["title"], item["published"], item["info"], item["url"], item["severity"], now()))
        meta_set(con, "demo_seeded", "1")


def collect_custom_sources(cfg):
    """采集用户新增的自定义 RSS 情报源。返回 (rows, states)。"""
    import httpx
    from xml.etree import ElementTree as ET
    from email.utils import parsedate_to_datetime
    import collectors
    rows, states = [], {}
    custom = cfg.get("custom_sources") or []
    if not custom:
        return rows, states
    with httpx.Client(timeout=httpx.Timeout(25, connect=10), follow_redirects=True,
                      transport=httpx.HTTPTransport(local_address="0.0.0.0"),
                      headers={"User-Agent": "TI-Workbench/1.0 (RSS reader)"}) as client:
        for src in custom:
            sid, name, feed = src["id"], src["name"], src["url"]
            at = now()
            try:
                resp = client.get(feed)
                resp.raise_for_status()
                raw = resp.content[:4 * 1024 * 1024]
                head = raw[:2000].upper()
                if b"<!DOCTYPE HTML" in head or b"<HTML" in head:
                    raise ValueError("该地址返回的是 HTML 网页而不是 RSS/Atom 订阅源，请查找站点的 feed/rss 地址")
                if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
                    raise ValueError("RSS 包含不支持的实体声明")
                root = ET.fromstring(raw)
                items = root.findall(".//item") or root.findall("{http://www.w3.org/2005/Atom}entry")
                out = []
                for entry in items[:100]:
                    def text(tag, atom):
                        return entry.findtext(tag) or entry.findtext("{http://www.w3.org/2005/Atom}" + atom) or ""
                    title = collectors.plain(text("title", "title"))
                    link = text("link", "link")
                    if not link:
                        el = entry.find("{http://www.w3.org/2005/Atom}link")
                        link = el.get("href", "") if el is not None else ""
                    if not title or not link.startswith(("http://", "https://")):
                        continue
                    try:
                        published = parsedate_to_datetime(text("pubDate", "published")).strftime("%Y-%m-%d %H:%M:%S")
                    except (TypeError, ValueError, OverflowError):
                        published = text("pubDate", "published")[:19]
                    summary = collectors.plain(text("description", "summary"))[:2000]
                    ids = sorted(set(re.findall(r"CVE-\d{4}-\d{4,}", title + " " + summary, re.I)))
                    out.append({"key": hashlib.sha256(link.encode()).hexdigest(), "source_id": sid,
                                "source": name, "cve": ", ".join(x.upper() for x in ids),
                                "title": title[:500], "published": published,
                                "info": summary or "请查看原文了解报道详情。", "url": link,
                                "severity": collectors.severity(title + " " + summary)})
                if not out:
                    raise ValueError("RSS 未返回有效条目")
                rows.extend({v["key"]: v for v in out}.values())
                states[sid] = {"ok": True, "count": len(out), "attempted": at, "last_success": at, "error": "", "name": name}
            except Exception as exc:
                states[sid] = {"ok": False, "count": 0, "attempted": at, "error": rss_error(exc), "name": name}
    return rows, states


def rss_error(exc):
    """把底层异常翻译成用户能看懂的失败原因。"""
    import httpx
    from xml.etree import ElementTree as ET
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        extra = {403: "（源站拒绝访问，可能需要登录、绑定 IP 或有反爬验证）",
                 404: "（地址不存在，请确认 RSS 路径）",
                 429: "（请求过于频繁被限流）"}.get(code, "")
        return f"源站返回 HTTP {code}{extra}"
    if isinstance(exc, httpx.ConnectTimeout):
        return "连接超时：无法建立到源站的连接（检查网络/代理/防火墙）"
    if isinstance(exc, httpx.ReadTimeout):
        return "读取超时：源站响应过慢"
    if isinstance(exc, httpx.ConnectError):
        return f"连接失败：{str(exc)[:120]}（DNS 解析失败、网络不通或被防火墙拦截）"
    if isinstance(exc, httpx.TooManyRedirects):
        return "重定向次数过多：该地址可能不是有效的 RSS"
    if isinstance(exc, ET.ParseError):
        return f"返回内容不是有效的 XML/RSS（第 {exc.position[0]} 行解析失败）：该地址可能返回的是 HTML 网页"
    if isinstance(exc, ValueError):
        return str(exc)[:180]
    return f"{type(exc).__name__}: {str(exc)[:150]}"


def run_sync(trigger="manual"):
    """直采 11 个内置公开情报源 + 用户自定义 RSS 源，记录同步历史。"""
    if not SYNC_LOCK.acquire(blocking=False):
        return {"ok": False, "error": "同步正在进行，请稍后刷新"}
    SYNC_STATE["running"] = True
    try:
        import collectors
        cfg = load_config()
        disabled = set(cfg.get("disabled_sources") or [])
        enabled = [s for s in collectors.SOURCES if s not in disabled]
        rows, states = asyncio.run(collectors.collect_all(sources=enabled))
        custom_cfg = {"custom_sources": [s for s in (cfg.get("custom_sources") or []) if s["id"] not in disabled]}
        custom_rows, custom_states = collect_custom_sources(custom_cfg)
        rows += custom_rows
        states.update(custom_states)
        finished = now()
        with db() as con:
            added, updated, changes = persist_rows(con, rows, finished)
            names = dict(collectors.SOURCES)
            names.update({s["id"]: s["name"] for s in (cfg.get("custom_sources") or [])})
            for key, state in states.items():
                state["name"] = names.get(key, key)
            meta_set(con, "collectors", json.dumps(states, ensure_ascii=False))
            meta_set(con, "last_attempt", finished)
            if rows:
                meta_set(con, "last_sync", finished)
            failed = [k for k, s in states.items() if not s["ok"] or s.get("partial")]
            meta_set(con, "last_error",
                     ("采集未完整：" + "、".join(names.get(k, k) for k in failed) + "；历史情报已保留。") if failed else "")
            con.execute("INSERT INTO ti_sync_history(time,trigger,fetched,added,updated,sources,changes) VALUES(?,?,?,?,?,?,?)",
                        (finished, trigger, len(rows), added, updated,
                         json.dumps(states, ensure_ascii=False), json.dumps(changes[:2000], ensure_ascii=False)))
            con.execute("DELETE FROM ti_sync_history WHERE id NOT IN (SELECT id FROM ti_sync_history ORDER BY id DESC LIMIT 100)")
        result = {"ok": bool(rows), "fetched": len(rows), "added": added, "updated": updated, "sources": states}
        if not rows:
            result["error"] = "所有来源采集失败（可能无外网访问）；历史情报已保留"
        push = push_sync_update(cfg, changes, added, updated)
        result["webhook"] = push
        with db() as con:
            con.execute("UPDATE ti_sync_history SET webhook=? WHERE id=(SELECT MAX(id) FROM ti_sync_history)",
                        (json.dumps(push, ensure_ascii=False),))
        SYNC_STATE["last_result"] = result
        return result
    finally:
        SYNC_STATE["running"] = False
        SYNC_LOCK.release()
# 微步 IOC 查询 endpoint：
# - global 区取自上游 defaults/plugins/tools/api/threatbook-io/*.yaml（api.threatbook.io /v2）
# - cn 区取自微步官方云 API 文档 x.threatbook.com/apiDocs（api.threatbook.cn /v3）
THREATBOOK_BASES = {"global": "https://api.threatbook.io", "cn": "https://api.threatbook.cn"}
IOC_TOOLS = {
    "global": {
        "ip": ("GET", "/v2/ip/query", "resource"),
        "domain": ("POST", "/v2/domain/query", "resource"),
        "file": ("POST", "/v2/file/query", "resource"),
        "url": ("POST", "/v2/url/query", "url"),
    },
    "cn": {
        "ip": ("GET", "/v3/scene/ip_reputation", "resource"),
        "domain": ("GET", "/v3/domain/query", "resource"),
        "file": ("GET", "/v3/file/report", "resource"),
        "url": ("GET", "/v3/url/report", "url"),
    },
}
# 无 apikey 时的演示响应（结构取自上游 tests/tool/test_api_plugin_security_tools.py 夹具）
IOC_DEMO = {
    "ip": {"severity": "info", "judgments": ["Whitelist", "IDC"], "confidence_level": "high",
           "is_malicious": False, "tags_classes": [{"tags": ["公有云"], "tags_type": "public_info"}],
           "basic": {"country": "美国", "country_code": "US", "carrier": "Google LLC"},
           "scene": "演示样例 · 配置微步 apikey 后可查询真实情报"},
    "domain": {"severity": "medium", "judgments": ["Malware"], "confidence_level": "medium",
               "is_malicious": True, "tags_classes": [{"tags": ["木马"], "tags_type": "malware"}],
               "categories": ["恶意软件"], "scene": "演示样例 · 配置微步 apikey 后可查询真实情报"},
    "file": {"severity": "high", "judgments": ["Trojan"], "is_malicious": True,
             "multiengines": {"detect_rate": "42/70"}, "scene": "演示样例 · 配置微步 apikey 后可查询真实情报"},
    "url": {"severity": "high", "judgments": ["Phishing"], "is_malicious": True,
            "scene": "演示样例 · 配置微步 apikey 后可查询真实情报"},
}


# 微步官方响应码（x.threatbook.com/apiDocs/start/response_code）：
# 0 成功；1 部分成功；2 无数据；3 报告生成中；4 未发现报告（需先提交扫描）；
# 5 无引擎数据；6 URL下载失败；7 URL下载中；-1 调用失败
IOC_OK_CODES = {
    0: "", 1: "部分成功（批量中个别对象格式无效或超限）",
    2: "查询成功：微步暂无该对象的情报数据",
    3: "报告正在生成中，请稍后重新查询",
    5: "查询成功：暂无反病毒引擎检测数据",
    7: "URL 下载分析中，请稍后重新查询",
}


def query_ioc(kind, resource, cfg):
    region = cfg.get("threatbook_region", "cn")
    if region not in IOC_TOOLS:
        region = "cn"
    if kind not in IOC_TOOLS[region]:
        return {"ok": False, "error": "不支持的查询类型"}
    resource = str(resource).strip()[:500]
    if not resource:
        return {"ok": False, "error": "请输入查询对象"}
    if kind == "file" and not re.fullmatch(r"[0-9a-fA-F]{32}|[0-9a-fA-F]{40}|[0-9a-fA-F]{64}", resource):
        return {"ok": False, "error": "文件哈希格式无效：请输入 32 位 MD5、40 位 SHA1 或 64 位 SHA256"}
    if kind == "url" and not resource.startswith(("http://", "https://")):
        return {"ok": False, "error": "URL 需包含协议，例如 https://example.com/path"}
    key = str(cfg.get("threatbook_api_key") or "").strip()
    if not key:
        return {"ok": True, "demo": True, "resource": resource, "data": {resource: IOC_DEMO[kind]}}
    import httpx
    method, path, param = IOC_TOOLS[region][kind]
    params = {param: resource, "apikey": key}
    if region == "cn":
        params["lang"] = "zh"
    try:
        with httpx.Client(timeout=float(cfg.get("timeout", 30))) as client:
            resp = client.request(method, THREATBOOK_BASES[region] + path, params=params)
            body = resp.json()
            code = body.get("response_code")
            # URL 无报告：自动提交一次扫描（cn /v3/url/scan），稍后可重查
            if kind == "url" and region == "cn" and code in (4, 6):
                scan = client.post(THREATBOOK_BASES["cn"] + "/v3/url/scan",
                                   params={"apikey": key, "url": resource}).json()
                if scan.get("response_code") in (0, 200):
                    return {"ok": True, "demo": False, "resource": resource, "data": scan.get("data", {}),
                            "note": "微步暂无该 URL 的历史报告，已自动提交扫描。请约 1 分钟后重新查询获取分析结果。"}
                return {"ok": False, "error": f"URL 提交扫描失败：{scan.get('verbose_msg') or scan.get('response_code')}"}
    except json.JSONDecodeError:
        return {"ok": False, "error": f"微步返回非 JSON 内容（HTTP {resp.status_code}），请确认区域选择与 Key 匹配"}
    except Exception as exc:
        return {"ok": False, "error": f"微步接口请求失败：{exc}"}
    msg = body.get("verbose_msg") or body.get("msg") or ""
    if code in IOC_OK_CODES or code == 200:
        return {"ok": True, "demo": False, "resource": resource,
                "data": body.get("data", {}), "note": IOC_OK_CODES.get(code, "")}
    if code == 4:
        hint = ("微步暂无该样本的分析报告。文件需先在微步官网（x.threatbook.com）上传分析后才能查询。"
                if kind == "file" else "微步暂无该 URL 的扫描报告，请稍后重试或先在微步官网提交扫描。")
        return {"ok": True, "demo": False, "resource": resource, "data": {}, "note": hint}
    hint = ""
    if code in (-1, 401):
        if "IP" in msg and ("Access" in msg or "访问" in msg):
            hint = "。国内版 Key 绑定了出口 IP 白名单，请在「我的KEY」中核对/更新绑定的 IP 为当前网络出口 IP"
        elif "权限" in msg or "Method" in msg:
            hint = "。当前 Key 未开通此接口权限，请在微步「API权限」页确认已授权该接口"
        else:
            hint = "。请检查：① Key 是否正确 ② 区域是否选对（x.threatbook.com 的 Key 选国内版，i.threatbook.io 选全球版）③ 国内版 Key 是否已绑定本机出口 IP"
    elif code == 429:
        hint = "。配额已用完或触发限流"
    return {"ok": False, "error": f"微步返回错误：{msg}（response_code={code}）{hint}", "raw": body}


SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "unknown": 0}
SEV_ZH = {"critical": "严重", "high": "高危", "medium": "中危", "low": "低危", "unknown": "未评级"}


def dingtalk_push(cfg, title, markdown):
    """向钉钉自定义机器人 webhook 推送 markdown 消息，支持加签。"""
    import base64
    import hmac
    import time
    import urllib.parse
    import httpx
    url = str(cfg.get("webhook_url") or "").strip()
    if not url.startswith("https://"):
        return {"ok": False, "error": "Webhook 地址无效：需为 https://oapi.dingtalk.com/robot/send?access_token=…"}
    secret = str(cfg.get("webhook_secret") or "").strip()
    if secret:
        ts = str(round(time.time() * 1000))
        sign = urllib.parse.quote_plus(base64.b64encode(
            hmac.new(secret.encode(), f"{ts}\n{secret}".encode(), hashlib.sha256).digest()))
        url += f"&timestamp={ts}&sign={sign}"
    try:
        with httpx.Client(timeout=15, transport=httpx.HTTPTransport(local_address="0.0.0.0")) as client:
            resp = client.post(url, json={"msgtype": "markdown", "markdown": {"title": title, "text": markdown}})
        body = resp.json()
    except Exception as exc:
        return {"ok": False, "error": f"推送请求失败：{exc}"}
    if body.get("errcode") == 0:
        return {"ok": True}
    return {"ok": False, "error": f"钉钉返回错误：{body.get('errmsg')}（errcode={body.get('errcode')}）"}


def build_update_markdown(changes, added, updated, cfg):
    """把本次同步的变更整理成钉钉 markdown 消息，按等级过滤与排序。"""
    min_rank = SEV_RANK.get(cfg.get("webhook_min_severity", "high"), 3)
    picked = [c for c in changes if SEV_RANK.get(c["severity"], 0) >= min_rank]
    picked.sort(key=lambda c: -SEV_RANK.get(c["severity"], 0))
    limit = int(cfg.get("webhook_max_items", 10))
    shown = picked[:limit]
    lines = [f"### 威胁情报更新 · {now()}",
             f"本次同步：新增 **{added}** 条，更新 **{updated}** 条；达到推送等级（{SEV_ZH.get(cfg.get('webhook_min_severity','high'),'高危')}及以上）共 **{len(picked)}** 条。", ""]
    for c in shown:
        cve = f"（{c['cve']}）" if c.get("cve") else ""
        tag = "新增" if c["action"] == "added" else "更新"
        lines.append(f"- **[{SEV_ZH.get(c['severity'], c['severity'])}]** {c['title']}{cve}")
        lines.append(f"  来源：{c['source']} · {tag} · {c.get('published','')[:10]}")
    if len(picked) > limit:
        lines.append(f"\n> 仅展示前 {limit} 条，其余 {len(picked) - limit} 条请打开工作台查看。")
    if not picked:
        lines.append("> 本次没有达到推送等级的情报变更。")
    return "\n".join(lines)


def push_sync_update(cfg, changes, added, updated):
    if not cfg.get("webhook_enabled"):
        return {"skipped": True, "reason": "未启用"}
    if not changes:
        return {"skipped": True, "reason": "无变更"}
    md = build_update_markdown(changes, added, updated, cfg)
    result = dingtalk_push(cfg, "威胁情报更新", md)
    result["pushed_items"] = len([c for c in changes if SEV_RANK.get(c["severity"], 0) >= SEV_RANK.get(cfg.get("webhook_min_severity", "high"), 3)])
    return result


def auto_sync_loop():
    """后台定时同步：每 60 秒检查一次开关与间隔，到期自动执行 run_sync。"""
    import time
    while True:
        time.sleep(60)
        try:
            cfg = load_config()
            if not cfg.get("auto_sync_enabled"):
                continue
            hours = float(cfg.get("auto_sync_hours", 12))
            with db() as con:
                last = meta_get(con, "last_attempt")
            if last:
                elapsed = (datetime.now() - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).total_seconds()
                if elapsed < hours * 3600:
                    continue
            print(f"[{now()}] 定时同步触发（每 {hours:g} 小时）")
            result = run_sync(trigger="auto")
            print(f"[{now()}] 定时同步完成：新增 {result.get('added', 0)}，更新 {result.get('updated', 0)}")
        except Exception as exc:
            print(f"[{now()}] 定时同步异常：{exc}")


SEVERITIES = ("critical", "high", "medium", "low", "unknown")
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
        ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon"}


class Handler(BaseHTTPRequestHandler):
    server_version = "TIWorkbench/1.0"

    def log_message(self, fmt, *args):
        pass

    def send_json(self, obj, status=200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > 1024 * 1024:
            return {}
        try:
            return json.loads(self.rfile.read(length))
        except json.JSONDecodeError:
            return {}

    def do_GET(self):
        url = urlparse(self.path)
        path, qs = url.path, parse_qs(url.query)
        if path == "/api/status":
            return self.api_status()
        if path == "/api/items":
            return self.api_items(qs)
        if path == "/api/config":
            cfg = load_config()
            return self.send_json({"region": cfg.get("threatbook_region", "global"),
                                   "timeout": cfg.get("timeout", 30),
                                   "has_key": bool(str(cfg.get("threatbook_api_key") or "").strip()),
                                   "auto_sync_enabled": bool(cfg.get("auto_sync_enabled")),
                                   "auto_sync_hours": cfg.get("auto_sync_hours", 12),
                                   "webhook_enabled": bool(cfg.get("webhook_enabled")),
                                   "webhook_url": cfg.get("webhook_url", ""),
                                   "has_webhook_secret": bool(str(cfg.get("webhook_secret") or "").strip()),
                                   "webhook_min_severity": cfg.get("webhook_min_severity", "high"),
                                   "webhook_max_items": cfg.get("webhook_max_items", 10)})
        if path == "/api/sources":
            return self.api_sources()
        if path == "/api/sync-history":
            return self.api_sync_history(qs)
        if path.startswith("/api/sync-history/"):
            return self.api_sync_detail(path.rsplit("/", 1)[-1])
        # 静态文件
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        target = (ROOT / "static" / rel).resolve()
        if not str(target).startswith(str(ROOT / "static")) or not target.is_file():
            return self.send_json({"error": "not found"}, 404)
        raw = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(target.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        path = urlparse(self.path).path
        body = self.read_body()
        if path == "/api/sync":
            return self.send_json(run_sync(trigger="manual"))
        if path == "/api/sources":
            return self.api_sources_modify(body)
        if path == "/api/ioc":
            return self.send_json(query_ioc(body.get("kind", "ip"), body.get("resource", ""), load_config()))
        if path == "/api/config":
            cfg = load_config()
            if "threatbook_api_key" in body:
                cfg["threatbook_api_key"] = str(body["threatbook_api_key"])[:200].strip()
            if body.get("threatbook_region") in THREATBOOK_BASES:
                cfg["threatbook_region"] = body["threatbook_region"]
            if isinstance(body.get("timeout"), (int, float)) and 5 <= body["timeout"] <= 300:
                cfg["timeout"] = int(body["timeout"])
            if "auto_sync_enabled" in body:
                cfg["auto_sync_enabled"] = bool(body["auto_sync_enabled"])
            if isinstance(body.get("auto_sync_hours"), (int, float)) and 0.5 <= body["auto_sync_hours"] <= 168:
                cfg["auto_sync_hours"] = float(body["auto_sync_hours"])
            if "webhook_enabled" in body:
                cfg["webhook_enabled"] = bool(body["webhook_enabled"])
            if "webhook_url" in body:
                cfg["webhook_url"] = str(body["webhook_url"])[:500].strip()
            if "webhook_secret" in body:
                cfg["webhook_secret"] = str(body["webhook_secret"])[:200].strip()
            if body.get("webhook_min_severity") in SEV_RANK:
                cfg["webhook_min_severity"] = body["webhook_min_severity"]
            if isinstance(body.get("webhook_max_items"), int) and 1 <= body["webhook_max_items"] <= 30:
                cfg["webhook_max_items"] = body["webhook_max_items"]
            save_config(cfg)
            return self.send_json({"ok": True, "has_key": bool(cfg["threatbook_api_key"]),
                                   "auto_sync_enabled": cfg["auto_sync_enabled"],
                                   "auto_sync_hours": cfg["auto_sync_hours"],
                                   "webhook_enabled": cfg["webhook_enabled"]})
        if path == "/api/webhook/test":
            cfg = load_config()
            if body.get("webhook_url"):
                cfg["webhook_url"] = str(body["webhook_url"])[:500].strip()
            if body.get("webhook_secret"):
                cfg["webhook_secret"] = str(body["webhook_secret"])[:200].strip()
            md = (f"### 威胁情报工作台 · 测试消息\n\n"
                  f"这是一条测试推送，发送时间 {now()}。\n\n"
                  f"收到此消息说明 Webhook 配置正确，同步到新的情报更新后将自动推送到本群。")
            return self.send_json(dingtalk_push(cfg, "威胁情报工作台测试", md))
        return self.send_json({"error": "not found"}, 404)

    def api_status(self):
        with db() as con:
            total = con.execute("SELECT COUNT(*) FROM ti_items").fetchone()[0]
            sources = [dict(r) for r in con.execute(
                "SELECT source,COUNT(*) AS count,MAX(published) AS latest,"
                "SUM(severity IN ('critical','high')) AS high FROM ti_items GROUP BY source ORDER BY count DESC")]
            severity_counts = dict(con.execute("SELECT severity,COUNT(*) FROM ti_items GROUP BY severity").fetchall())
            meta = dict(con.execute("SELECT key,value FROM ti_meta").fetchall())
        collectors_state = {}
        try:
            collectors_state = json.loads(meta.get("collectors") or "{}")
        except json.JSONDecodeError:
            pass
        cfg = load_config()
        next_sync = ""
        if cfg.get("auto_sync_enabled") and meta.get("last_attempt"):
            try:
                from datetime import timedelta
                due = datetime.strptime(meta["last_attempt"], "%Y-%m-%d %H:%M:%S") + timedelta(hours=float(cfg.get("auto_sync_hours", 12)))
                next_sync = due.strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
        self.send_json({"total": total, "sources": sources, "severity_counts": severity_counts,
                        "last_sync": meta.get("last_sync", ""), "last_attempt": meta.get("last_attempt", ""),
                        "last_error": meta.get("last_error", ""), "demo_seeded": meta.get("demo_seeded") == "1",
                        "collectors": collectors_state, "syncing": SYNC_STATE["running"],
                        "auto_sync_enabled": bool(cfg.get("auto_sync_enabled")),
                        "auto_sync_hours": cfg.get("auto_sync_hours", 12), "next_sync": next_sync,
                        "has_key": bool(str(cfg.get("threatbook_api_key") or "").strip())})

    def api_items(self, qs):
        def arg(name):
            return (qs.get(name) or [""])[0][:200]
        q, sev, source = arg("q"), arg("severity"), arg("source")
        try:
            page = max(1, min(int(arg("page") or 1), 100000))
        except ValueError:
            page = 1
        where, args = ["1=1"], []
        if q:
            where.append("instr(lower(title || ' ' || cve || ' ' || info),lower(?))>0")
            args.append(q)
        if sev in SEVERITIES:
            where.append("severity=?")
            args.append(sev)
        if source:
            where.append("source=?")
            args.append(source)
        clause = " WHERE " + " AND ".join(where)
        with db() as con:
            rows = con.execute("SELECT * FROM ti_items" + clause + " ORDER BY published DESC,id LIMIT 24 OFFSET ?",
                               (*args, (page - 1) * 24)).fetchall()
            total = con.execute("SELECT COUNT(*) FROM ti_items" + clause, args).fetchone()[0]
        self.send_json({"items": [dict(r) for r in rows], "total": total, "page": page})

    # ---------- 情报源配置 ----------
    def api_sources(self):
        import collectors
        cfg = load_config()
        with db() as con:
            meta = dict(con.execute("SELECT key,value FROM ti_meta").fetchall())
            counts = {r["source"]: dict(r) for r in con.execute(
                "SELECT source,COUNT(*) AS count,MAX(published) AS latest FROM ti_items GROUP BY source")}
        try:
            states = json.loads(meta.get("collectors") or "{}")
        except json.JSONDecodeError:
            states = {}
        builtin_urls = {
            "threatbook": "https://x.threatbook.com/v5/node/vul_module/notice/next",
            "aliyun": "https://avd.aliyun.com/high-risk/list",
            "tophant": "https://vip.tophant.com/api/data/vuln_list",
            "chaitin": "https://stack.chaitin.com/api/v2/vuln/list/",
            "nvd": "https://nvd.nist.gov/feeds/json/cve/2.0/nvdcve-2.0-recent.json.gz",
            "cisa": "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
            "tenable": "https://www.tenable.com/cve/feeds?sort=newest",
        }
        items = []
        disabled = set(cfg.get("disabled_sources") or [])
        for sid, name in collectors.SOURCES.items():
            url = builtin_urls.get(sid) or (collectors.NEWS_FEEDS[sid][1] if sid in collectors.NEWS_FEEDS else "")
            st = states.get(sid, {})
            c = counts.get(name, {})
            items.append({"id": sid, "name": name, "url": url, "type": "builtin",
                          "kind": "新闻 RSS" if sid in collectors.NEWS_FEEDS else "漏洞通告",
                          "enabled": sid not in disabled,
                          "count": c.get("count", 0), "latest": c.get("latest", ""),
                          "last_ok": st.get("ok"), "partial": st.get("partial", False),
                          "last_error": st.get("error", ""),
                          "last_success": st.get("last_success", "")})
        for src in cfg.get("custom_sources") or []:
            st = states.get(src["id"], {})
            c = counts.get(src["name"], {})
            items.append({"id": src["id"], "name": src["name"], "url": src["url"], "type": "custom",
                          "kind": "自定义 RSS", "enabled": src["id"] not in disabled,
                          "count": c.get("count", 0), "latest": c.get("latest", ""),
                          "last_ok": st.get("ok"), "partial": st.get("partial", False),
                          "last_error": st.get("error", ""),
                          "last_success": st.get("last_success", "")})
        self.send_json({"items": items})

    def api_sources_modify(self, body):
        action = body.get("action")
        cfg = load_config()
        custom = cfg.get("custom_sources") or []
        if action == "add":
            name = str(body.get("name") or "").strip()[:50]
            url = str(body.get("url") or "").strip()[:500]
            if not name or not url.startswith(("http://", "https://")):
                return self.send_json({"ok": False, "error": "请填写名称和合法的 RSS 地址（http/https）"}, 422)
            if any(s["name"] == name for s in custom):
                return self.send_json({"ok": False, "error": "已存在同名情报源"}, 422)
            # 新增前先验证 RSS 可采集
            sid = "custom-" + digest([name, url])[:12]
            cfg["custom_sources"] = custom + [{"id": sid, "name": name, "url": url}]
            rows, states = collect_custom_sources({"custom_sources": [{"id": sid, "name": name, "url": url}]})
            st = states.get(sid, {})
            if not st.get("ok"):
                return self.send_json({"ok": False, "error": f"RSS 验证失败：{st.get('error', '未知错误')}。请确认地址返回标准 RSS/Atom。"}, 422)
            save_config(cfg)
            with db() as con:
                added, updated, _ = persist_rows(con, rows, now())
            return self.send_json({"ok": True, "id": sid, "fetched": st.get("count", 0), "added": added})
        if action == "delete":
            sid = body.get("id")
            remain = [s for s in custom if s["id"] != sid]
            if len(remain) == len(custom):
                return self.send_json({"ok": False, "error": "只能删除自定义情报源；内置源可用「停用」"}, 422)
            cfg["custom_sources"] = remain
            cfg["disabled_sources"] = [d for d in (cfg.get("disabled_sources") or []) if d != sid]
            save_config(cfg)
            return self.send_json({"ok": True})
        if action in ("enable", "disable"):
            import collectors
            sid = body.get("id")
            valid = set(collectors.SOURCES) | {s["id"] for s in custom}
            if sid not in valid:
                return self.send_json({"ok": False, "error": "情报源不存在"}, 422)
            disabled = set(cfg.get("disabled_sources") or [])
            if action == "disable":
                disabled.add(sid)
            else:
                disabled.discard(sid)
            cfg["disabled_sources"] = sorted(disabled)
            save_config(cfg)
            return self.send_json({"ok": True, "enabled": action == "enable"})
        return self.send_json({"ok": False, "error": "未知操作"}, 422)

    # ---------- 同步历史 ----------
    def api_sync_history(self, qs):
        try:
            page = max(1, min(int((qs.get("page") or ["1"])[0]), 10000))
        except ValueError:
            page = 1
        with db() as con:
            rows = con.execute("SELECT id,time,trigger,fetched,added,updated FROM ti_sync_history ORDER BY id DESC LIMIT 20 OFFSET ?",
                               ((page - 1) * 20,)).fetchall()
            total = con.execute("SELECT COUNT(*) FROM ti_sync_history").fetchone()[0]
        self.send_json({"items": [dict(r) for r in rows], "total": total, "page": page})

    def api_sync_detail(self, hid):
        with db() as con:
            row = con.execute("SELECT * FROM ti_sync_history WHERE id=?", (hid,)).fetchone()
        if not row:
            return self.send_json({"error": "记录不存在"}, 404)
        d = dict(row)
        d["sources"] = json.loads(d["sources"])
        d["changes"] = json.loads(d["changes"])
        try:
            d["webhook"] = json.loads(d.get("webhook") or "") if d.get("webhook") else None
        except json.JSONDecodeError:
            d["webhook"] = None
        self.send_json(d)


def main():
    cfg = load_config()
    if not CONFIG_PATH.exists():
        save_config(cfg)
    init_db()
    seed_demo()
    port = int(cfg.get("port", 8686))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}/"
    threading.Thread(target=auto_sync_loop, daemon=True).start()
    print(f"威胁情报工作台已启动：{url}")
    if cfg.get("auto_sync_enabled"):
        print(f"定时同步已开启：每 {cfg.get('auto_sync_hours', 12):g} 小时")
    print("按 Ctrl+C 停止服务。")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")


if __name__ == "__main__":
    main()