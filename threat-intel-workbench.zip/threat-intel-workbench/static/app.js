"use strict";
const $ = (id) => document.getElementById(id);
const SEV_LABEL = { critical: "严重", high: "高危", medium: "中危", low: "低危", unknown: "未评级" };
const state = { page: 1, total: 0, q: "", severity: "", source: "", items: [] };

async function api(path, opts) {
  const resp = await fetch(path, opts);
  return resp.json();
}
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------- 状态与来源卡片 ---------- */
async function loadStatus() {
  const s = await api("/api/status");
  const sc = s.severity_counts || {};
  const syncLbl = s.auto_sync_enabled
    ? `定时同步已开启 · 每 ${s.auto_sync_hours} 小时` + (s.next_sync ? ` · 下次 ${s.next_sync.slice(5, 16)}` : "")
    : "定时同步未开启";
  $("stats").innerHTML = [
    ["情报库总数", s.total],
    ["严重 / 高危", (sc.critical || 0) + " / " + (sc.high || 0)],
    ["情报来源", (s.sources || []).length],
    ["最近同步", s.last_sync || "尚未同步"],
  ].map(([l, n]) => `<div class="stat"><div class="num">${esc(n)}</div><div class="lbl">${esc(l)}</div></div>`).join("")
    + `<div class="stat"><div class="num" style="font-size:14px;line-height:34px">${s.auto_sync_enabled ? "⏱ 自动" : "手动"}</div><div class="lbl">${esc(syncLbl)}</div></div>`;

  const banner = $("banner");
  const notes = [];
  if (s.demo_seeded && !s.last_sync) notes.push("当前展示内置演示情报（离线可用）。点击「同步最新情报」从 11 个公开源直采真实数据，无需任何 API Key。");
  if (s.last_error) notes.push(s.last_error);
  banner.textContent = notes.join(" ");
  banner.classList.toggle("hidden", !notes.length);

  $("sources").innerHTML = (s.sources || []).map((src) => {
    return `<div class="source ${state.source === src.source ? "active" : ""}" data-source="${esc(src.source)}">
      <div class="name">${esc(src.source)}</div>
      <div class="cnt">${src.count}</div>
      <div class="meta">高危+ ${src.high} · 最新 ${esc((src.latest || "").slice(0, 10))}</div>
    </div>`;
  }).join("") || '<p class="hint">暂无情报，请点击「同步最新情报」。</p>';
  document.querySelectorAll(".source").forEach((el) => el.addEventListener("click", () => {
    state.source = state.source === el.dataset.source ? "" : el.dataset.source;
    $("f-source").value = state.source;
    state.page = 1; loadItems(); loadStatus();
  }));

  const sel = $("f-source"), cur = sel.value;
  sel.innerHTML = '<option value="">全部来源</option>' + (s.sources || []).map(x => `<option ${x.source === cur ? "selected" : ""}>${esc(x.source)}</option>`).join("");
  $("btn-sync").disabled = !!s.syncing;
  $("btn-sync").textContent = s.syncing ? "同步中…" : "同步最新情报";
  return s;
}

/* ---------- 情报列表 ---------- */
async function loadItems() {
  const p = new URLSearchParams({ page: state.page });
  if (state.q) p.set("q", state.q);
  if (state.severity) p.set("severity", state.severity);
  if (state.source) p.set("source", state.source);
  const d = await api("/api/items?" + p);
  state.total = d.total; state.items = d.items;
  $("items").innerHTML = d.items.map((it, i) => `
    <div class="item" data-i="${i}">
      <div class="row1"><span class="sev ${esc(it.severity)}">${SEV_LABEL[it.severity] || it.severity}</span>
        <span class="cve">${esc(it.cve)}</span></div>
      <h3>${esc(it.title)}</h3>
      <div class="info">${esc(it.info)}</div>
      <div class="foot"><span>${esc(it.source)}</span><span>${esc((it.published || "").slice(0, 16))}</span></div>
    </div>`).join("") || '<p class="hint">没有匹配的情报。</p>';
  document.querySelectorAll(".item").forEach(el => el.addEventListener("click", () => openDetail(state.items[+el.dataset.i])));
  const pages = Math.max(1, Math.ceil(d.total / 24));
  $("pg-info").textContent = `第 ${state.page} / ${pages} 页 · 共 ${d.total} 条`;
  $("pg-prev").disabled = state.page <= 1;
  $("pg-next").disabled = state.page >= pages;
}

function openDetail(it) {
  $("m-sev").className = "sev " + it.severity;
  $("m-sev").textContent = SEV_LABEL[it.severity] || it.severity;
  $("m-title").textContent = it.title;
  $("m-meta").innerHTML = `<span>来源：${esc(it.source)}</span><span>CVE：${esc(it.cve || "—")}</span><span>发布：${esc(it.published)}</span><span>入库：${esc(it.synced)}</span>`;
  $("m-info").textContent = it.info;
  const link = $("m-url");
  if (it.url) { link.href = it.url; link.classList.remove("hidden"); } else link.classList.add("hidden");
  $("modal").classList.remove("hidden");
}

/* ---------- IOC 查询 ---------- */
async function loadConfigHint() {
  const c = await api("/api/config");
  $("ioc-hint").textContent = c.has_key
    ? `已配置微步 API Key（${c.region === "cn" ? "国内版 api.threatbook.cn" : "全球版 api.threatbook.io"}），查询将返回真实情报。若失败请确认区域与 Key 领取站点一致。`
    : "未配置微步 API Key，当前返回演示数据。可在右上角「设置」中填入 Key（微步官网可免费领取）。";
}
async function queryIoc() {
  const btn = $("ioc-query"); btn.disabled = true; btn.textContent = "查询中…";
  try {
    const d = await api("/api/ioc", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: $("ioc-kind").value, resource: $("ioc-resource").value }) });
    const out = $("ioc-result"), note = $("ioc-note");
    out.classList.remove("hidden");
    note.classList.toggle("hidden", !(d.ok && d.note));
    note.textContent = d.note || "";
    out.textContent = d.ok
      ? (d.demo ? "【演示数据】\n" : "") + JSON.stringify(d.data, null, 2)
      : "查询失败：" + d.error;
  } finally { btn.disabled = false; btn.textContent = "查询"; }
}

/* ---------- 情报源配置 ---------- */
async function loadSources() {
  const d = await api("/api/sources");
  $("src-table").querySelector("tbody").innerHTML = d.items.map(s => {
    let status;
    if (!s.enabled) status = '<span class="hint">已停用</span>';
    else if (s.last_ok === undefined || s.last_ok === null) status = '<span class="hint">未采集</span>';
    else if (s.last_ok && s.partial) status = `<span style="color:var(--med)">部分成功</span><div class="err">${esc(s.last_error)}</div>`;
    else if (s.last_ok) status = '<span class="ok">成功</span>' + (s.last_error ? `<div class="err">${esc(s.last_error)}</div>` : "");
    else status = `<span class="fail">失败</span><div class="err">${esc(s.last_error)}</div>`;
    const ops = [];
    ops.push(`<button class="btn ghost toggle-src" data-id="${esc(s.id)}" data-action="${s.enabled ? "disable" : "enable"}">${s.enabled ? "停用" : "启用"}</button>`);
    if (s.type === "custom") ops.push(`<button class="btn ghost del-src" data-id="${esc(s.id)}">删除</button>`);
    return `<tr class="${s.enabled ? "" : "disabled-row"}">
      <td><b>${esc(s.name)}</b></td>
      <td>${esc(s.kind)}</td>
      <td class="url"><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.url)}</a></td>
      <td>${s.count}</td>
      <td>${status}</td>
      <td class="ops">${ops.join(" ")}</td>
    </tr>`;
  }).join("");
  document.querySelectorAll(".del-src").forEach(b => b.addEventListener("click", async () => {
    if (!confirm("删除该自定义情报源？（已入库的情报会保留）")) return;
    const d = await api("/api/sources", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", id: b.dataset.id }) });
    showSrcMsg(d.ok ? "已删除。" : d.error, !d.ok);
    loadSources();
  }));
  document.querySelectorAll(".toggle-src").forEach(b => b.addEventListener("click", async () => {
    const d = await api("/api/sources", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: b.dataset.action, id: b.dataset.id }) });
    showSrcMsg(d.ok ? (b.dataset.action === "disable" ? "已停用：下次同步起不再采集该源（已入库情报保留）。" : "已启用：下次同步恢复采集。") : d.error, !d.ok);
    loadSources();
  }));
}
function showSrcMsg(text, isErr) {
  const el = $("src-msg");
  el.textContent = text;
  el.classList.toggle("fail", !!isErr);
}
async function addSource() {
  const btn = $("src-add"); btn.disabled = true; btn.textContent = "验证中…";
  try {
    const d = await api("/api/sources", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "add", name: $("src-name").value, url: $("src-url").value }) });
    showSrcMsg(d.ok
      ? `新增成功：验证采集 ${d.fetched} 条，入库 ${d.added} 条。下次同步起自动包含该源。`
      : "新增失败：" + d.error, !d.ok);
    if (d.ok) { $("src-name").value = ""; $("src-url").value = ""; loadSources(); loadStatus(); loadItems(); }
  } finally { btn.disabled = false; btn.textContent = "验证并新增"; }
}

/* ---------- 同步历史 ---------- */
const hist = { page: 1, total: 0, detail: null };
async function loadHistory() {
  const d = await api("/api/sync-history?page=" + hist.page);
  hist.total = d.total;
  $("hist-list").innerHTML = d.items.map(r => `
    <div class="hist-row" data-id="${r.id}">
      <span class="time">${esc(r.time)}</span>
      <span class="sev ${r.trigger === "auto" ? "low" : "medium"}">${r.trigger === "auto" ? "定时" : "手动"}</span>
      <span>采集 <b>${r.fetched}</b> 条</span>
      <span class="ok">新增 <b>${r.added}</b></span>
      <span style="color:var(--med)">更新 <b>${r.updated}</b></span>
      <span class="hint">点击查看明细 →</span>
    </div>`).join("") || '<p class="hint">暂无同步记录。点击「同步最新情报」开始第一次同步。</p>';
  document.querySelectorAll(".hist-row").forEach(el => el.addEventListener("click", () => openHistDetail(el.dataset.id)));
  const pages = Math.max(1, Math.ceil(d.total / 20));
  $("hist-info").textContent = `第 ${hist.page} / ${pages} 页 · 共 ${d.total} 次同步`;
  $("hist-prev").disabled = hist.page <= 1;
  $("hist-next").disabled = hist.page >= pages;
}
async function openHistDetail(id) {
  const d = await api("/api/sync-history/" + id);
  hist.detail = d;
  $("h-title").textContent = `同步详情 · ${d.time}（${d.trigger === "auto" ? "定时" : "手动"}）`;
  let pushHtml = "";
  if (d.webhook) {
    pushHtml = d.webhook.skipped
      ? `<span class="hint">钉钉推送：跳过（${esc(d.webhook.reason)}）</span>`
      : d.webhook.ok
        ? `<span class="ok">钉钉推送：成功（${d.webhook.pushed_items || 0} 条达标）</span>`
        : `<span class="fail">钉钉推送失败：${esc(d.webhook.error || "")}</span>`;
  }
  $("h-summary").innerHTML = `<span>采集 ${d.fetched} 条</span><span>新增 ${d.added} 条</span><span>更新 ${d.updated} 条</span>${pushHtml}`;
  $("h-sources").querySelector("tbody").innerHTML = Object.entries(d.sources).map(([k, s]) => `
    <tr><td><b>${esc(s.name || k)}</b></td>
    <td>${s.ok ? (s.partial ? '<span style="color:var(--med)">部分成功</span>' : '<span class="ok">成功</span>') : '<span class="fail">失败</span>'}</td>
    <td>${s.count}</td><td class="err">${esc(s.error || "")}</td></tr>`).join("");
  const srcs = [...new Set(d.changes.map(c => c.source))];
  $("h-source").innerHTML = '<option value="">全部来源</option>' + srcs.map(s => `<option>${esc(s)}</option>`).join("");
  $("h-action").value = "";
  renderHistChanges();
  $("hist-modal").classList.remove("hidden");
}
function renderHistChanges() {
  const d = hist.detail; if (!d) return;
  const act = $("h-action").value, src = $("h-source").value;
  const list = d.changes.filter(c => (!act || c.action === act) && (!src || c.source === src));
  $("h-chg-filter").textContent = `（${list.length} 条${d.changes.length >= 2000 ? "，明细最多保留 2000 条" : ""}）`;
  $("h-changes").innerHTML = list.map(c => `
    <div class="chg-row">
      <span class="sev ${c.action === "added" ? "low" : "medium"}">${c.action === "added" ? "新增" : "更新"}</span>
      <span class="sev ${esc(c.severity)}">${SEV_LABEL[c.severity] || c.severity}</span>
      <span class="chg-title" data-id="${esc(c.id)}">${esc(c.title)}</span>
      <span class="hint">${esc(c.source)} · ${esc(c.cve || "")} · ${esc((c.published || "").slice(0, 10))}</span>
    </div>`).join("") || '<p class="hint">本次同步没有新增或更新（所有情报均已是最新）。</p>';
  document.querySelectorAll(".chg-title").forEach(el => el.addEventListener("click", async () => {
    const it = state.items.find(x => x.id === el.dataset.id);
    if (it) return openDetail(it);
    const d = await api("/api/items?q=" + encodeURIComponent(el.textContent.slice(0, 60)));
    const found = (d.items || []).find(x => x.id === el.dataset.id);
    if (found) openDetail(found);
  }));
}

/* ---------- 设置 ---------- */
async function openSettings() {
  const c = await api("/api/config");
  $("s-region").value = c.region; $("s-timeout").value = c.timeout; $("s-key").value = "";
  $("s-auto").checked = !!c.auto_sync_enabled;
  $("s-hours").value = String(c.auto_sync_hours);
  if (!$("s-hours").value) $("s-hours").value = "12";
  $("s-status").textContent = c.has_key ? "已保存 Key（出于安全不回显）" : "尚未配置 Key";
  $("w-enabled").checked = !!c.webhook_enabled;
  $("w-url").value = c.webhook_url || "";
  $("w-secret").value = "";
  $("w-secret").placeholder = c.has_webhook_secret ? "已保存加签密钥；留空保持不变" : "SEC 开头；未设置加签可留空";
  $("w-sev").value = c.webhook_min_severity || "high";
  $("w-max").value = c.webhook_max_items || 10;
  $("w-status").textContent = "";
  const st = await api("/api/status");
  $("s-next").textContent = st.auto_sync_enabled && st.next_sync ? `下次自动同步：${st.next_sync}` : "";
  $("settings").classList.remove("hidden");
}
async function saveSettings() {
  const body = { threatbook_region: $("s-region").value, timeout: +$("s-timeout").value,
                 auto_sync_enabled: $("s-auto").checked, auto_sync_hours: +$("s-hours").value,
                 webhook_enabled: $("w-enabled").checked, webhook_url: $("w-url").value.trim(),
                 webhook_min_severity: $("w-sev").value, webhook_max_items: +$("w-max").value };
  const key = $("s-key").value;
  if (key.trim()) body.threatbook_api_key = key.trim();
  else if (key === " ") body.threatbook_api_key = "";
  const secret = $("w-secret").value;
  if (secret.trim()) body.webhook_secret = secret.trim();
  else if (secret === " ") body.webhook_secret = "";
  const d = await api("/api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  $("s-status").textContent = d.ok ? "已保存" : "保存失败";
  loadConfigHint(); loadStatus();
}
async function testWebhook() {
  const btn = $("w-test"); btn.disabled = true; btn.textContent = "发送中…";
  $("w-status").textContent = "";
  try {
    const body = {};
    if ($("w-url").value.trim()) body.webhook_url = $("w-url").value.trim();
    if ($("w-secret").value.trim()) body.webhook_secret = $("w-secret").value.trim();
    const d = await api("/api/webhook/test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    $("w-status").textContent = d.ok ? "测试消息已发送，请到钉钉群确认。" : "发送失败：" + d.error;
    $("w-status").classList.toggle("fail", !d.ok);
  } finally { btn.disabled = false; btn.textContent = "发送测试消息"; }
}

/* ---------- 事件绑定 ---------- */
document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === t));
  ["feed", "ioc", "sources", "history"].forEach(name =>
    $("tab-" + name).classList.toggle("hidden", t.dataset.tab !== name));
  if (t.dataset.tab === "sources") loadSources();
  if (t.dataset.tab === "history") loadHistory();
}));
$("btn-sync").addEventListener("click", async () => {
  $("btn-sync").disabled = true; $("btn-sync").textContent = "同步中…（约 1-2 分钟）";
  try { await api("/api/sync", { method: "POST" }); }
  finally { state.page = 1; await loadStatus(); await loadItems(); }
});
$("btn-settings").addEventListener("click", openSettings);
$("s-save").addEventListener("click", saveSettings);
$("w-test").addEventListener("click", testWebhook);
$("s-close").addEventListener("click", () => $("settings").classList.add("hidden"));
$("m-close").addEventListener("click", () => $("modal").classList.add("hidden"));
$("modal").addEventListener("click", (e) => { if (e.target === $("modal")) $("modal").classList.add("hidden"); });
$("settings").addEventListener("click", (e) => { if (e.target === $("settings")) $("settings").classList.add("hidden"); });
$("f-apply").addEventListener("click", () => { state.q = $("f-q").value.trim(); state.severity = $("f-sev").value; state.source = $("f-source").value; state.page = 1; loadItems(); });
$("f-q").addEventListener("keydown", (e) => { if (e.key === "Enter") $("f-apply").click(); });
$("f-reset").addEventListener("click", () => { $("f-q").value = ""; $("f-sev").value = ""; $("f-source").value = ""; state.q = state.severity = state.source = ""; state.page = 1; loadItems(); loadStatus(); });
$("pg-prev").addEventListener("click", () => { state.page--; loadItems(); });
$("pg-next").addEventListener("click", () => { state.page++; loadItems(); });
$("ioc-query").addEventListener("click", queryIoc);
$("ioc-resource").addEventListener("keydown", (e) => { if (e.key === "Enter") queryIoc(); });
$("src-add").addEventListener("click", addSource);
$("hist-prev").addEventListener("click", () => { hist.page--; loadHistory(); });
$("hist-next").addEventListener("click", () => { hist.page++; loadHistory(); });
$("h-close").addEventListener("click", () => $("hist-modal").classList.add("hidden"));
$("hist-modal").addEventListener("click", (e) => { if (e.target === $("hist-modal")) $("hist-modal").classList.add("hidden"); });
$("h-action").addEventListener("change", renderHistChanges);
$("h-source").addEventListener("change", renderHistChanges);

loadStatus(); loadItems(); loadConfigHint();