# 威胁情报工作台 TI Workbench（Windows 本地独立版）

基于开源安全运营项目（Apache-2.0，来源归属见 NOTICE 文件）提取的**威胁情报功能**，剥离了原项目的登录鉴权、Agent 编排、工单审批等平台依赖，可在 Windows 本地独立运行，直接浏览威胁情报内容，并支持向钉钉群推送情报更新。

## 功能

| 功能 | 说明 | 是否需要 Key |
|---|---|---|
| 情报订阅 | 直采 11 个公开情报源：微步在线、阿里云漏洞库、长亭、斗象、NVD、CISA KEV（已知在野利用）、Tenable、4 个安全新闻 RSS | 不需要 |
| 情报源配置 | 查看全部情报源（地址/类型/库存/最近采集状态）；新增自定义 RSS/Atom 源（先验证再保存，失败显示具体原因）；所有源可停用/启用，自定义源可删除 | 不需要 |
| 定时同步 | 设置中可开启自动同步开关，间隔可选 1/3/6/12/24 小时、2 天、每周；服务运行期间后台自动采集 | 不需要 |
| 钉钉推送 | 配置钉钉群自定义机器人 Webhook（支持加签），每次同步发现新情报后自动推送摘要到群；可设推送等级下限与条数上限，支持测试消息 | 需要钉钉机器人 Webhook |
| 同步历史 | 每次同步（手动/定时）记录：各来源采集状态与条数、本次新增/更新的每条情报明细，可按来源/变更类型筛选，点击标题查看详情 | 不需要 |
| 情报浏览 | 来源卡片、等级/关键词/来源筛选、分页、详情弹窗、原文链接 | 不需要 |
| 离线演示 | 首次运行内置 10 条演示情报，无外网也能看到界面内容 | 不需要 |
| IOC 查询 | 微步 ThreatBook IP / 域名 / 文件哈希 / URL 信誉查询；URL 无历史报告时自动提交扫描 | 需要微步 API Key（不填则返回演示数据） |

## 快速开始（Windows）

1. 安装 [Python 3.11+](https://www.python.org/downloads/)（安装时勾选 *Add python.exe to PATH*）
2. 双击 `start.bat`
   - 首次运行自动创建虚拟环境并安装唯一依赖 `httpx`
   - 浏览器自动打开 `http://127.0.0.1:8686/`
3. 点击 **「同步最新情报」** 从公开源采集真实数据（约 1-2 分钟，需外网）

停止服务：在命令行窗口按 `Ctrl+C` 或直接关闭窗口。

### 微步 IOC 查询（可选）

1. 到微步官网免费领取 API Key（国内版 x.threatbook.com / 全球版 i.threatbook.io，登录后在「我的KEY」页面领取）
2. 页面右上角「设置」→ **选择与 Key 领取站点一致的区域**、填入 Key → 保存
   - x.threatbook.com 领取的 Key → 国内版 `api.threatbook.cn`（默认）
   - i.threatbook.io 领取的 Key → 全球版 `api.threatbook.io`
   - 国内版 Key 若绑定了出口 IP，需在绑定 IP 的网络环境下使用
3. 切到「IOC 查询」标签，输入 IP / 域名 / 哈希 / URL 查询

Key 只保存在本地 `config.json`，不会上传到任何第三方。

**IOC 查询结果说明**（按微步官方响应码处理）：
- 「无数据 / 报告生成中 / 下载中」是正常业务状态，会显示提示而非报错
- 文件哈希需为 32 位 MD5 / 40 位 SHA1 / 64 位 SHA256；样本需先在微步官网上传分析过才有报告
- URL 无历史报告时自动提交一次扫描（`/v3/url/scan`），约 1 分钟后重查即可拿到结果
- 鉴权失败会提示具体原因：Key 无效 / 出口 IP 未绑定 / 接口未授权 / 配额用尽

### 情报源配置与同步历史

- 「情报源配置」标签：查看 11 个内置源 + 自定义源的地址、类型、库存条数、最近采集状态
  - **新增**：填写名称和 RSS 地址，先验证可采集再保存；失败时显示具体原因（HTTP 403/404、连接超时、DNS 失败、返回 HTML 而非 RSS 等）
  - **停用/启用**：任何源（含内置）都可停用，停用后下次同步不再采集，已入库情报保留
  - **删除**：自定义源可删除（已入库情报保留）
- 「同步历史」标签：每次同步一行记录（时间 / 手动或定时 / 采集 / 新增 / 更新条数），点击查看各来源明细和本次新增/更新的每条情报，保留最近 100 次

**关于阿里云漏洞库"部分成功"**：阿里云高危列表页（avd.aliyun.com/high-risk/list）部署了反爬浏览器验证（滑块/JS 挑战），无法也不应程序化绕过。采集器检测到验证后会自动回退到官网首页公开发布的最新漏洞列表，因此状态显示"部分成功"——数据仍在持续更新，只是覆盖面小于高危列表。这不影响其他 10 个来源；如不需要该源可在情报源配置中停用。

### 定时同步

「设置」→「定时同步」→ 勾选开关并选择间隔（1 小时 ~ 每周）→ 保存。
服务运行期间后台按间隔自动采集；首页状态卡显示下次同步时间。关闭服务后定时同步暂停，下次启动自动恢复。

### 钉钉推送（Webhook）

1. 钉钉群 →「群设置 → 机器人 → 添加机器人 → 自定义（Webhook）」，复制 Webhook 地址；安全设置建议选「加签」，复制 SEC 开头的密钥
2. 工作台「设置」→「钉钉推送」→ 勾选启用、粘贴地址与密钥 → 选择推送等级下限（默认高危及以上）和每条消息最多展示条数 → 保存
3. 点「发送测试消息」确认群里能收到
4. 之后每次同步（手动或定时）发现新增/更新情报，自动推送 markdown 摘要到群：标题、等级、CVE、来源、日期；达到等级下限的条目按严重度排序展示
5. 「同步历史」详情中可查看每次推送的结果（成功/失败原因/跳过原因）

Webhook 地址与加签密钥只保存在本地 `config.json`。

## 目录结构

```
threat-intel-workbench/
├── start.bat              # Windows 一键启动
├── server.py              # 本地后端（标准库 HTTP 服务 + SQLite 情报库）
├── collectors.py          # 上游公开源采集器（原样复用，Apache-2.0）
├── config.json            # 本地配置（端口 / 微步 Key / 超时，首次运行生成）
├── requirements.txt       # 唯一依赖：httpx
├── data/
│   ├── demo_items.json    # 内置离线演示情报
│   └── threat_intel.db    # SQLite 情报库（运行后生成）
├── static/                # 前端页面（原生 HTML/JS/CSS，无构建）
├── LICENSE                # Apache-2.0（上游许可证）
└── NOTICE                 # 来源归属说明
```

## 配置项（config.json）

| 键 | 默认 | 说明 |
|---|---|---|
| `port` | 8686 | 本地服务端口 |
| `threatbook_api_key` | "" | 微步 API Key，留空则 IOC 查询返回演示数据 |
| `threatbook_region` | "cn" | `cn`=api.threatbook.cn（x.threatbook.com 的 Key）/ `global`=api.threatbook.io |
| `timeout` | 30 | 微步接口请求超时（秒），也可在页面设置中修改 |
| `auto_sync_enabled` | false | 定时同步开关 |
| `auto_sync_hours` | 12 | 定时同步间隔（小时，0.5~168） |
| `webhook_enabled` | false | 钉钉推送开关 |
| `webhook_url` | "" | 钉钉机器人 Webhook 地址 |
| `webhook_secret` | "" | 加签密钥（SEC 开头，可选） |
| `webhook_min_severity` | "high" | 推送等级下限：critical/high/medium/low/unknown |
| `webhook_max_items` | 10 | 每条推送消息最多展示条数（1~30） |

## 与上游的对应关系

- `collectors.py` ← `defaults/plugins/aegis-scenes-runtime/aegis_scenes/intelligence_collectors.py`（原样复用）
- 情报入库/筛选/分页逻辑 ← 同目录 `threat_intelligence.py`（剥离 FastAPI 鉴权、翻译、资产匹配、每日调度等平台耦合）
- IOC 查询 endpoint 与参数 ← `defaults/plugins/tools/api/threatbook-io/*.yaml`
- 演示 IOC 响应结构 ← `tests/tool/test_api_plugin_security_tools.py` 测试夹具

上游的资产影响匹配、LLM 翻译、工单整改闭环依赖完整平台，未包含在本提取版中。

## 说明

- 所有情报均来自各厂商**公开接口**，采集器只读、不执行任何扫描或利用行为。
- 演示数据（离线样例与无 Key 时的 IOC 结果）均有明确标注，不代表真实威胁判定。
- 仅供防御性安全研究与内部情报浏览使用。