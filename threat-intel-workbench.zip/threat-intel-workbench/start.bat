@echo off
setlocal
cd /d "%~dp0"
title Threat Intel Workbench

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 未找到 Python。请先安装 Python 3.11+：https://www.python.org/downloads/
  echo 安装时请勾选 "Add python.exe to PATH"。
  pause
  exit /b 1
)

if not exist ".venv" (
  echo 首次运行：创建虚拟环境...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"

python -c "import httpx" >nul 2>nul
if errorlevel 1 (
  echo 安装依赖 httpx...
  python -m pip install --disable-pip-version-check httpx
)

echo 启动 威胁情报工作台（浏览器将自动打开）...
python server.py
pause